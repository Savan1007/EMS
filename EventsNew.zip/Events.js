import React from 'react';
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { role } from "../features/authSlice";

const CardViewer = ({data}) => {
    const cardObj = data.map((element) => {
        return(
            <div className="col-sm-3 m-5">
                    <div className="card">
                        <div className="card-header">{element.eventName}</div>
                        <div className="card-body">
                            {element.eventDes}
                            <br/>
                            <br/>
                            Venue : {element.eventVenue}
                            <br/>
                            Date and Time : {element.eventTime}
                            <br/>
                        </div>
                        <div className="card-footer">Organized By {element.organizeBy}</div>
                    </div>
                    </div>
        )
    });
    return (
        <div>
            <div className="row d-flex align-items-center">
                {cardObj}
            </div> 
        </div>
    )
}
function Events() {
    const currentRole = useSelector(role);
    const Dummydata = [
        {
        eventName:'AI ML Learning',
        eventDes:'Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive webpages.',
        eventVenue:'Valasd',
        eventTime:'10:30',
        organizeBy:'Gracy'
        },
        {
            eventName:'Web App',
            eventDes:'Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive!',
            eventVenue:'Valasd',
            eventTime:'11:30',
            organizeBy:'Gracy'
        },
        {
            eventName: 'Fun with Python',
            eventDes:'Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive!',
            eventVenue:'Valasd',
            eventTime:'5:30',
            organizeBy:'Gracy'
        },
        {
            eventName: 'Fun with Python',
            eventDes:'Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive!',
            eventVenue:'Valasd',
            eventTime:'5:30',
            organizeBy:'Gracy'
        },
        {
            eventName: 'Fun with Python',
            eventDes:'Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive!',
            eventVenue:'Valasd',
            eventTime:'5:30',
            organizeBy:'Gracy'
        },
    ]
    if(currentRole === "MGR")
    {
        return (
            <div className="container-fluid">
                <div className='col-lg-11 pt-5'>
                    <h3 className='text-primary '>Events</h3>
                    <p className='bar pb-3'>Upcomming Events</p>
                </div>
                <div className='container'>
                    <CardViewer data={Dummydata}/>
                </div> 
            </div>
        )
    }
    else if(currentRole=== "EMP")
    {
        return (
            <div className="container-fluid">
                <div className='col-lg-11 pt-5'>
                    <h3 className='text-primary '>Events</h3>
                    <p className='bar pb-3'>Upcomming Events</p>
                </div>
                <div className='container'>
                    <CardViewer />
                </div> 
            </div>
        )
    }
    else{
        return (
            <div className="container-fluid">
                <div className='col-lg-11 pt-5'>
                    <h3 className='text-primary '>Events</h3>
                    <p className='bar pb-3'>Upcomming Events</p>
                </div>
                <div className='container'>
                    <CardViewer data={Dummydata}/>
                </div> 
            </div>
        )
    }
}

export default Events
