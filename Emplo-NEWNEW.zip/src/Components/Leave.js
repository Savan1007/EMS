import React, { useState } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { role } from "../features/authSlice";

const TableViewer = ({data,filter}) => {
    let filteredData = data.filter((element) =>{
        return element.empid.includes(filter) || element.LeaveCat.includes(filter) ||element.empName.includes(filter) || element.leaveStatus.includes(filter);
    });

    const uiObj = filteredData.map((element) => {
        return(
            <tr>
                <td scope='col'>
                    <Link to={`view/leave/${element.empid}`}>{element.empid}</Link>
                </td>
                <td scope='col'>
                    <Link to={`view/leave/${element.empid}`}>{element.empName}</Link>
                </td>
                <td scope='col'>{element.LeaveCat}</td>
                <td scope='col'>{element.leaveStatus}</td>
            </tr>
        )
    });
    return (
        <table>
            <thread>
                <tr>
                    <th scope="col">Employee ID</th>
                    <th scope="col">Employee Name</th>
                    <th scope="col">Leave Category</th>
                    <th scope="col">Status</th>
                </tr>
                <br />
                {uiObj}
            </thread>
        </table>
    )

}
function Leave() {
    const currentRole = useSelector(role);
    const [filter, setFilter] = useState("");
    const DummyData = [
        {
            empid:'19DCS088',
            empName:'Gracy Patel',
            LeaveCat:'Sick',
            appliedOn:'abc pqr xyz',
            leaveStatus:'Approved'
        },
        {
            empid:'19DCS018',
            empName:'Gracy',
            LeaveCat:'Family function',
            appliedOn:'abc pqr xyz',
            leaveStatus:'Pending'
        },
        {
            empid:'19DCS011',
            empName:'Patel',
            LeaveCat:'Complete Files',
            appliedOn:'abc pqr xyz',
            leaveStatus:'Pending'
        },
    ]
    if(currentRole === "MGR"){
        return(
            <div className="container-fluid">
                <div className='col-lg-11 pt-5'>
                    <h3 className='text-primary '>Leave</h3>
                    <p className='bar pb-3'>Employees seeking Leave</p>
                </div>
                <input 
                 type='search'
                 placeholder='filter'
                 className='form-control'
                 value={filter}
                 onChange={(e) => {
                    setFilter(e.target.value);
                    }}
                />
                <div className='row g-5 mt-1'>
                    <div className='col-lg-11'>
                        <TableViewer data={DummyData} filter={filter}/>
                    </div>
                </div>
            </div>
        )
    }
    else if(currentRole === "EMP"){
        return(
            <div className="container-fluid">
                <div className='row'>
                    <div className='col-lg-11 d-flex justify-content-end align-items-center'>
                        <button
                            className='btn btn-outline-dark'
                        >
                            Apply Leave
                        </button>
                    </div>
                </div>
                <div className='col-lg-11'>
                    <h3 className='text-primary '>Leave</h3>
                    <p className='bar pb-3'>Applied Leave</p>
                </div>
                <input 
                 type='search'
                 placeholder='filter'
                 className='form-control'
                />
            </div>
        )
    }
    else{
        return(
            <div className="container-fluid">
                <div className='col-lg-11'>
                    <h3 className='text-primary '>Leave</h3>
                    <p className='bar pb-3'>Applied Leave</p>
                </div>
                <input 
                 type='search'
                 placeholder='filter'
                 className='form-control'
                />
            </div>
        )
    }
}

export default Leave
