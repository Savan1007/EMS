import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { role,empId} from "../features/authSlice";
import axios from "axios";


const TableViewer = ({ data, filter }) => {
  let filteredData = data.filter((element) => {
    return element.empId.includes(filter) || element.empName.includes(filter);
  });

  const uiObj = filteredData.map((element) => {
    return (
      <tr>
        {" "}
        <td scope='col'>
          <Link to={`view/profile/${element.empId}`}>{element.empId}</Link>
        </td>
        <td scope='col'> {element.empName} </td>{" "}
        <td scope='col'> {element.empDesign} </td>{" "}
        <td scope='col'> {element.email} </td>{" "}
      </tr>
    );
  });
  return (
    <table>
      <thead>
        <tr>
          <th scope='col'> Employee Id</th>
          <th scope='col'> Name</th>
          <th scope='col'> Designation</th>
          <th scope='col'> Email</th>
        </tr>
      </thead>
      <br />
      {uiObj}
    </table>
  );
};

function Department() {
  const currentRole = useSelector(role);
  const [filter, setFilter] = useState("");
  const [addMode, setAddMode] = useState(false);
  const [newEmpId, setEmpId] = useState("");
  const [currentdata,setcurrentData] = useState(null);
  const currentuserId = useSelector(empId);
  useEffect(() => {
    const fetchDepartment = async () => {
      const {status,data} = await axios.get(`https://emplo-eye.herokuapp.com/dept/${currentuserId}`)
      if(status===200)
      {
        setcurrentData(data.result);
        console.log(data);
      }
    }
    fetchDepartment()
  }, [])
  {/*const DummyData = [
    {
      empId: "001",
      empName: "Savan Pedhadiya",
      empDesign: "Student",
      email: "xyz@123.com",
    },
    {
      empId: "002",
      empName: "Gracy Patel",
      empDesign: "Student",
      email: "xyz@123.com",
    },
    {
      empId: "002",
      empName: "Gracy Patel",
      empDesign: "Student",
      email: "xyz@123.com",
    },
    {
      empId: "002",
      empName: "Gracy Patel",
      empDesign: "Student",
      email: "xyz@123.com",
    },
  ];
*/}
  if (currentRole === "MGR") {
    if (addMode) {
      return (
        <div className='container-fluid pb-5'>
          <button
            class='btn btn-floating'
            onClick={() => {
              setAddMode(false);
            }}
          >
            <i class='fas fa-arrow-circle-left'></i>
          </button>
          <div className='row d-flex justify-content-center pb-5'>
            <div className='col-lg-6'>
              <h5 className='bar'> Add a new Employee </h5>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  // Method With Network Call
                }}
              >
                <label class='form-label mt-2' for='form1Example1'>
                  Employee ID
                </label>

                <input
                  type='text'
                  id='form1Example1'
                  class='form-control'
                  onChange={(e) => {
                    setEmpId(e.target.value);
                  }}
                  required
                />

                <label class='form-label mt-2' for='form1Example1'>
                  Name
                </label>
                <input
                  type='text'
                  id='form1Example1'
                  class='form-control'
                  onChange={(e) => {
                    setEmpId(e.target.value);
                  }}
                  required
                />

                <label class='form-label mt-2' for='form1Example1'>
                  Role
                </label>
                <input
                  type='text'
                  id='form1Example1'
                  class='form-control'
                  onChange={(e) => {
                    setEmpId(e.target.value);
                  }}
                  required
                />
                <label class='form-label mt-2' for='form1Example1'>
                  Email
                </label>
                <input
                  type='text'
                  id='form1Example1'
                  class='form-control'
                  onChange={(e) => {
                    setEmpId(e.target.value);
                  }}
                  required
                />
                <label class='form-label mt-2' for='form1Example1'>
                  Designation
                </label>
                <input
                  type='text'
                  id='form1Example1'
                  class='form-control'
                  onChange={(e) => {
                    setEmpId(e.target.value);
                  }}
                  required
                />
                <label class='form-label mt-2' for='form1Example1'>
                  Salary
                </label>
                <input
                  type='text'
                  id='form1Example1'
                  class='form-control'
                  onChange={(e) => {
                    setEmpId(e.target.value);
                  }}
                  required
                />
                <label class='form-label mt-2' for='form1Example1'>
                  Department
                </label>
                <input
                  type='text'
                  id='form1Example1'
                  class='form-control'
                  onChange={(e) => {
                    setEmpId(e.target.value);
                  }}
                  required
                />
                <button
                  className='btn btn-outline-primary mt-5 px-5'
                  type='submit'
                >
                  Add
                </button>
                <button
                  className='btn btn-outline-black mt-5 mx-5'
                  type='reset'
                >
                  Reset
                </button>
              </form>
            </div>
          </div>
        </div>
      );
    } else {
      return (
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-lg-11 d-flex justify-content-end align-items-center'>
              <button
                className='btn btn-outline-dark'
                onClick={() => {
                  setAddMode(true);
                }}
              >
                Add Employee
              </button>
            </div>
          </div>

          <div className='row g-5'>
            <div className='col-lg-11 '>
              {/* // ! Change with variable */}
              <h3 className='text-primary '>IT Department</h3>
              <p className='bar pb-3'>Employees</p>
              <input
                type='search'
                placeholder='filter'
                className='form-control'
                value={filter}
                onChange={(e) => {
                  setFilter(e.target.value);
                }}
              />
            </div>
          </div>

          <div className='row g-5 mt-1'>
            <div className='col-lg-12 '>
              {/* // ! Change with variable */}
              <TableViewer data={currentdata} filter={filter} />
            </div>
          </div>
        </div>
      );
    }
  } else if (currentRole === "EMP") {
    return <></>;
  } else if (currentRole === "ADM") {
    return <></>;
  }
}

export default Department;
