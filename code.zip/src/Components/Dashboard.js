import React, { useEffect } from "react";

function DashBoard() {
  return <div className='container'></div>;
}

export default DashBoard;
