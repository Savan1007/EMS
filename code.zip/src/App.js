import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Layout from "./Components/Layout";
import DashBoard from "./Components/Dashboard";
import Login from "./Components/Login";
import { useSelector } from "react-redux";
import { isAuthenticated } from "./features/authSlice";
import Department from "./Components/Department";

function App() {
  const auth = useSelector(isAuthenticated);

  if (!auth) {
    return <Login />;
  } else {
    return (
      <Router>
        <Layout>
          <Switch>
            <Route path='/Dashboard' exact>
              {/* DashBoard Component */}
              <DashBoard />
            </Route>
            <Route path='/department' exact>
              {/* department Component */}
              <Department />
            </Route>
            <Route path='/project' exact>
              {/* project Component */}
            </Route>
            <Route path='/tasks' exact>
              {/* tasks Component */}
            </Route>
            <Route path='/leave' exact>
              {/* leave Component */}
            </Route>
            <Route path='/salary' exact>
              {/* salary Component */}
            </Route>
            <Route path='/events' exact>
              {/* events Component */}
            </Route>
          </Switch>
        </Layout>
      </Router>
    );
  }
}

export default App;
