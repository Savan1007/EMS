const express = require("express")
const App = express()
const PORT = process.env.PORT || 5000
const cors = require('cors')
const mongoose = require('mongoose') 
const Employee = require("./Models/employee")
const Leave = require("./Models/leave")
const Task = require("./Models/task")
const Project = require("./Models/project")
const dburi = "mongodb+srv://admin:admin@123@cluster0.bpscl.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"

App.use(express.json())
App.use(cors())

mongoose.connect(dburi, { useNewUrlParser: true, useUnifiedTopology: true }).then(() => {
    App.listen(PORT)
    console.log("Connected to database")
})

// login
App.post('/login', (req, res) => {
    const newempId = Employee.findOne({
        password: req.body.password,
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        if(!result) return res.send({message: "Invalid password"}).status(404)
        if(result.empId != req.body.empId) return res.send({message: "Invalid Employee Id"}).status(404)
        res.send({message: "login ", auth: true, result})
    })
})

// Add New Employee From Manager Side
App.post('/new/employee', (req,res) => {
    const newEmployee = new Employee({
        empId: req.body.empId,
        empName: req.body.empName,
        password: req.body.password,
        role: req.body.role,
        email: req.body.email,
        empDesign: req.body.empDesign,
        empSalary: req.body.empSalary,
        deptName: req.body.deptName,
    })
    newEmployee.save().then((result) => {
        res.send(result)
    })
    .catch((err) => {
        console.log(err)
    })
})
// Update profile
App.post('/update/employee', (req,res) => {
    Employee.updateOne({
        empId: req.body.empId
    }, {
        empName: req.body.empName,
        password: req.body.password,
        gender: req.body.gender,
        dob: req.body.dob,
        email: req.body.email,
        phoneNo: req.body.phoneNo,
        address: req.body.address,
        accNo: req.body.accNo,
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})
// Get personal Profile
App.get('/profile/:empId', (req,res) => {
    Employee.findOne({
        empId: req.params.empId
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        if(!result) return res.send({message: "user not found"}).status(404)
        res.send(result)
    })
})

// take leave application from employee side
App.post('/new/leave', (req,res) => {
    const newLeave = new Leave({
        appliedBy: req.body.appliedBy,
        startDate: req.body.startDate,
        endDate: req.body.endDate,
        reason: req.body.reason,
    })
    newLeave.save().then((result) => {
        res.send(result)
    })
    .catch((err) => {
        console.log(err)
    })
})
//print all leaves application which status is pending
App.get('/leave', (req,res) => {
    Leave.find({
        status: "Pending"
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        if(!result) return res.send({message: "user not found"}).status(404)
        res.send(result)
    })
})
// update leave statue to approved from manager side
App.post('/update/leave', (req,res) => {
    Leave.updateOne({
        appliedBy: req.body.appliedBy
    }, {
        status: req.body.status
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})


// Assigned task from manager side
App.post('/new/task', (req, res) => {
    const newTask = new Task({
        appliedBy: req.body.appliedBy,
        taskName: req.body.taskName,
        taskDesc: req.body.taskDesc,
        dueDate: req.body.dueDate,
        appliedTo: req.body.appliedTo,
    })
    newTask.save().then((result) => {
        res.send(result)
    })
    .catch((err) => {
        console.log(err)
    })
})

// Get all task that he assinged [manager ]
App.get('/task/:appliedBy', (req,res) => {
    Task.find({
        appliedBy: req.params.appliedBy
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})

// Get all task [employee ]
App.get('/empTask/:appliedTo', (req,res) => {
    Task.find({
        appliedTo: req.params.appliedTo
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})

// Complete task
App.post('/update/task', (req,res) => {
    Task.updateOne({
        _id: req.body._id
    }, {
        status: req.body.status
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})


// Assigned project from manager side
App.post('/new/project', (req, res) => {
    const newProject = new Project({
        projectName: req.body.projectName,
        projectDesc: req.body.projectDesc,
        deptName: req.body.deptName
    })
    newProject.save().then((result) => {
        res.send(result)
    })
    .catch((err) => {
        console.log(err)
    })
})
// ADd project member
App.post('/addProjMem', (req,res) => {
    Project.updateOne({
        _id: req.body._id
    }, {
        appliedTo: req.body.appliedTo
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})
// Complete project
App.post('/update/project', (req,res) => {
    Project.updateOne({
        _id: req.body._id
    }, {
        status: req.body.status
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})
// get project list in perticular dept
App.get('/projList/:deptName', (req,res) => {
    Project.find({
        deptName: req.params.deptName
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})
// Get info of perticular project
App.get('/proj/:_id', (req,res) => {
    Project.findOne({
        _id: req.params._id
    }, function (err, result){
        if(err) return res.send({message: "server error"})
        res.send(result)
    })
})

App.post('/proj/emp', (req, res) => {
    const newempId = Project.find({
        deptName: req.body.deptName,
    }, function (err, result){
        console.log("result" + result)
        if(err) return res.send({message: "server error"})
        if(!result) return res.send({message: "No project in department"}).status(404)
        if(!result.appliedTo.includes(req.body.empId)) return res.send({message: "No project"}).status(404)
        res.send(result)
    })
})