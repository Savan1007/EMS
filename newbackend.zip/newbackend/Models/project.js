const mongoose = require('mongoose')
const projectSchema = new mongoose.Schema({
    projectName: {
        type: String,
        required: true,
    },
    projectDesc: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        default: "Pending",
    },
    deptName: {
        type: String,
        required: true,
    },
    appliedTo: {
        type: [],
    }
})

const Project = mongoose.model("Projects", projectSchema)
module.exports = Project