const mongoose = require('mongoose')
const taskSchema = new mongoose.Schema({
    appliedBy: {
        type: String,
        required: true,
    },
    taskName: {
        type: String,
        required: true,
    },
    taskDesc: {
        type: String,
        required: true,
    },
    dueDate: {
        type: Date,
        required: true,
    },
    status: {
        type: String,
        default: "Pending",
    },
    appliedTo: {
        type: String,
        required: true,
    }
})

const Task = mongoose.model("Tasks", taskSchema)
module.exports = Task