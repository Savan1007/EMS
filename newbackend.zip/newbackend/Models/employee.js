const mongoose = require("mongoose")
const employeeSchema = new mongoose.Schema({
    empId: {
        type: String,
        required: true,
        unique: true
    },
    empName: {
        type: String,
        required: true,
    },
    password: {
        type: String,
        required: true,
    },
    role: {
        type: String,
        required: true,
    },
    dob: {
        type: Date, 
    },
    gender: {
        type: String,
    },
    email: {
        type: String,
        required: true,
    },
    phoneNo: {
        type: String,
    },
    address: {
        type: String,
    },
    empDesign: {
        type: String,
        required: true,
    },
    empSalary: {
        type: String,
        required: true,
    },
    accNo: {
        type: String,
    },
    deptName: {
        type: String,
        required: true,
    }
})

const Employee = mongoose.model("Employee", employeeSchema)
module.exports = Employee